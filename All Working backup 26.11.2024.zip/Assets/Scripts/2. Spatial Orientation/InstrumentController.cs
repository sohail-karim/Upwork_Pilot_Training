using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class InstrumentManager : MonoBehaviour
{
    public Transform airplanceTransform;
    public Transform indicatorTransform;

    public Transform gyroTransform;  // Reference to the GYRO instrument's transform (airplane object)
    public Transform rbiTransform;   // Reference to the RBI instrument's transform (arrow object)


    SilhouetteManager silhouetteManager;
    // Min and max rotation angles for GYRO and RBI
    private static InstrumentManager _instance;

    public static InstrumentManager instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<InstrumentManager>();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
    }
    void Start()
    {
        silhouetteManager = SilhouetteManager.instance;
        // Initialize random rotations for both instruments
        SetRandomRotation();
        
    }

    void SetRandomRotation()
    {
        // Randomize GYRO rotation
        float randomGyroRotation = Random.Range(0, 360);
        gyroTransform.rotation = Quaternion.Euler(0, 0, randomGyroRotation); // Rotate around Z-axis

        // Randomize RBI rotation
        float randomRbiRotation = Random.Range(0, 360);
        rbiTransform.rotation = Quaternion.Euler(0, 0, randomRbiRotation); // Rotate around Z-axis

        float randomAirplanceRotation = Random.Range(0, 360);
        airplanceTransform.rotation = Quaternion.Euler(0, 0, randomAirplanceRotation); // Rotate around Z-axis

        float randomIndicatorRotation = Random.Range(0, 360);
        indicatorTransform.rotation = Quaternion.Euler(0, 0, randomIndicatorRotation); // Rotate around Z-axis

        StartCoroutine(WaitForCompleteRotation(randomAirplanceRotation));
    }


    IEnumerator WaitForCompleteRotation(float AeroplaneRotation)
    {
        silhouetteManager.SetRandomSilhouetteRotations(AeroplaneRotation);
        yield return null;

    }

    public void ChangeRotations()
    {
        SetRandomRotation();
    }
}
