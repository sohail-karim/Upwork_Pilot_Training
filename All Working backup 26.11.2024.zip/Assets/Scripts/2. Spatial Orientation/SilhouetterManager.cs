using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class SilhouetteManager : MonoBehaviour
{
    public Transform airplaneTransform;    // Reference to the airplane
    public Transform[] silhouetteTransforms; // Array of silhouettes
    public Button[] silhouetteButtons;     // Array of buttons linked to silhouettes


    int correctIndex;
    // Store the rotation of the airplane

    private static SilhouetteManager _instance;

    public static SilhouetteManager instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<SilhouetteManager>();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
    }

    void Start()
    {
        // Set random rotations for the silhouettes
    //    SetRandomSilhouetteRotations();

        // Add listeners to the buttons to check answers
        for (int i = 0; i < silhouetteButtons.Length; i++)
        {
            int index = i;  // To avoid closure issue in lambda
            silhouetteButtons[i].onClick.AddListener(() => CheckAnswer(index));
        }
    }

    public void SetRandomSilhouetteRotations(float AeroplaneRotation)
    {
        // Randomly select one silhouette to match the airplane rotation
        correctIndex = Random.Range(0, silhouetteTransforms.Length); // Random index from 0 to 3 (for 4 silhouettes)

        // Rotate the silhouettes: one matches the airplane, others differ
        for (int i = 0; i < silhouetteTransforms.Length; i++)
        {
            if (i == correctIndex)  // The selected silhouette should match the airplane rotation
            {
                Debug.Log("Correct silhouette at index " + i + " with Rotation : " + AeroplaneRotation);
                silhouetteTransforms[i].rotation = Quaternion.Euler(0, 0, AeroplaneRotation);  // Set to airplane rotation
            }
            else  // The other silhouettes should have random rotations
            {
                float randomRotation = Random.Range(0f, 360f);  // Random rotation for other silhouettes
                silhouetteTransforms[i].rotation = Quaternion.Euler(0, 0, randomRotation);  // Set random rotation
            }
        }
    }


    // Method to check if the selected silhouette matches the airplane's rotation
    public void CheckAnswer(int selectedIndex)
    {

        // Get the Image component of the selected silhouette
        Image selectedImage = silhouetteTransforms[selectedIndex].GetComponentInParent<Image>();

        // Change the alpha of the selected silhouette to 255 (fully opaque)
        Color newColor = selectedImage.color;
        newColor.a = 1f;  // Set alpha to 1 (fully opaque)
        selectedImage.color = newColor;  // Apply the new color to the image

        // Check if the selected silhouette is the correct one
        if (selectedIndex == correctIndex)  // If the correct silhouette is clicked
        {
            Debug.Log("Correct! This silhouette matches the airplane.");

        }
        else  // If the incorrect silhouette is clicked
        {
            Debug.Log("Incorrect! This silhouette does not match the airplane.");
        }
    }
}
