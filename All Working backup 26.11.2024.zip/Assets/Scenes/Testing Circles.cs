using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestingCircles : MonoBehaviour
{
    public GameObject circleScreen;
    public GameObject circlePrefab;


    private void Start()
    {
        SpawnCircles(16, 150);
    }


    public void SpawnCircles(int gridsize, float minDistance)
    {
        RectTransform circleScreenRect = circleScreen.GetComponent<RectTransform>();
        float screenWidth = circleScreenRect.rect.width;
        float screenHeight = circleScreenRect.rect.height;

        float resolutionScaleFactor = screenWidth / 1920f; // Scale based on current resolution
        float adjustedMinDistance = minDistance * resolutionScaleFactor;

        float circleRadius = circlePrefab.GetComponent<RectTransform>().rect.width / 2;
        float availableWidth = screenWidth - 2 * circleRadius;
        float availableHeight = screenHeight - 2 * circleRadius;

        Debug.Log($"Screen Area: {availableWidth}x{availableHeight}, Adjusted Min Distance: {adjustedMinDistance}");

        List<Vector3> attemptedPositions = new List<Vector3>();

        for (int i = 0; i < gridsize; i++)
        {
            bool positionValid = false;
            Vector3 spawnPosition = Vector3.zero;

            int attempts = 0;
            while (!positionValid && attempts < 100)
            {
                attempts++;
                float randomX = Random.Range(-availableWidth / 2, availableWidth / 2);
                float randomY = Random.Range(-availableHeight / 2, availableHeight / 2);
                spawnPosition = new Vector3(randomX, randomY, 0) + circleScreenRect.position;

                positionValid = true;
                foreach (Vector3 pos in attemptedPositions)
                {
                    if (Vector3.Distance(spawnPosition, pos) < adjustedMinDistance)
                    {
                        positionValid = false;
                        break;
                    }
                }
            }

            if (positionValid)
            {
                GameObject circle = Instantiate(circlePrefab, spawnPosition, Quaternion.identity, circleScreen.transform);
                circle.GetComponent<RectTransform>().localScale = Vector3.one;
                attemptedPositions.Add(spawnPosition);
            }
            else
            {
                Debug.LogWarning($"Unable to place circle {i} after 100 attempts.");
            }
        }
    }



}
