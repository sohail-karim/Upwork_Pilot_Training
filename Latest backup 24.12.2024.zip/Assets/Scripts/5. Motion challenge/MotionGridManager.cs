using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MotionGridManager : MonoBehaviour
{
    public LevelData[] levelData;  // Add a reference to the LevelData scriptable object
    public int rows;
    public int cols;
    public float cellSize = 1f;
    public int CurrentLevel;


    public Color[] ObstaclesColors;
    List<int> ColorsUsedList = new List<int>();

    [Space]
    public List<SpawnedObjectData> spawnedObjects = new List<SpawnedObjectData>();
    [Space]
    int grid4levels;

    [Space]
    public int MovesDone = 0;
    public TextMeshProUGUI text_MoveDone;
    public int PuzzleSolved= 0;

    [Space]
    public TextMeshProUGUI LevelText;
    public TextMeshProUGUI timer_Text;
    private float timeRemaining = 300f;
    private bool isTimerRunning = true;
    public Slider slider_timer;

    public Sprite[] bgSprites;

    public GameObject gridBackgroundPrefab;
    public Transform gridBackground;
    public GameObject redPrefab;
    public GameObject blackHolePrefab;
    public GameObject obstaclePrefab;

    [HideInInspector] public Vector3[,] gridPositions;
    [HideInInspector] public bool[,] gridOccupied;

    [HideInInspector] public Dictionary<Vector2Int, GameObject> gridCellsDict = new Dictionary<Vector2Int, GameObject>();

    [HideInInspector] public int redRow, redCol;
    [HideInInspector] public int blackRow, blackCol;

    public GameObject[,] gridCells;

    List<int> PlayerlevelsList = new List<int>();


    public static MotionGridManager instance;

    private void Awake() { instance = this; }

    void Start()
    {
        Debug.Log(ObstaclesColors.Length);
        slider_timer.maxValue = timeRemaining;
        PlayerlevelsList.Clear();
        CurrentLevel = 1;
        StartMotionGame();
    }

    void Update()
    {
        if (isTimerRunning)
        {
            if (timeRemaining > 0)
            {
                timeRemaining -= Time.deltaTime; // Decrease time by delta time
                slider_timer.value = timeRemaining;
                UpdateTimerDisplay();
            }
            else
            {
                isTimerRunning = false;
                timeRemaining = 0;
                UpdateTimerDisplay();
                GameOver();
                Debug.Log("Timer has ended.");
            }
        }
    }

    public void GameOver()
    {
        StartCoroutine(StartNewGame());
    }
    public void LevelSkip()
    {
        int ThisLevel = CurrentLevel;
        ThisLevel++;
        PlayerPrefs.SetInt("MotionCurrentLevel", ThisLevel);
        StartMotionGame();
    }

    public void UpdatemovesDone()
    {
        MovesDone++;
        text_MoveDone.text = MovesDone.ToString();
    }

    IEnumerator StartNewGame()
    {
        
        Debug.Log("Solved Puzzled " + PuzzleSolved);
        yield return new WaitForSeconds(1f);
        StartMotionGame();


        yield return null;
    }

    void UpdateTimerDisplay()
    {
        // Convert seconds into minutes and seconds format
        int minutes = Mathf.FloorToInt(timeRemaining / 60);
        int seconds = Mathf.FloorToInt(timeRemaining % 60);

        // Update the Text component
        timer_Text.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    void ClearGrid()
    {
        spawnedObjects.Clear();
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        Destroy(player);
        GameObject blackHole = GameObject.FindGameObjectWithTag("Finish");
        Destroy(blackHole);
        foreach (Transform child in gridBackground)
        {
            Destroy(child.gameObject); // Destroy each child GameObject
        }
    }

     public  void StartMotionGame()
     {
        ColorsUsedList.Clear();
        MovesDone = 0; 
        text_MoveDone.text = MovesDone.ToString();
       grid4levels = Random.Range(1, 72);  // select a random level of 4*4 Grid
        while (PlayerlevelsList.Contains(grid4levels))
        {
            grid4levels = Random.Range(1, 72);  // select a random level of 4*4 Grid
        }

        PlayerlevelsList.Add(grid4levels);
        LevelText.text ="Level " + CurrentLevel.ToString();
        if (levelData != null)
        {
            rows = levelData[grid4levels - 1].rows;
            cols = levelData[grid4levels - 1].cols;
            if(gridBackground.childCount > 0)
            {
                ClearGrid();
            }
       
            GenerateGrid();
            SpawnRedAndBlackHole();
            PlaceObstacles();
        }
        else
        {
            Debug.LogError("LevelData is not assigned!");
        }
     }

    void GenerateGrid()
    {
        gridPositions = new Vector3[rows, cols];
        gridOccupied = new bool[rows, cols];

        float padding = 0.1f;
        Camera mainCamera = Camera.main;
        float totalGridWidth = cols * (cellSize + padding) - padding;
        float totalGridHeight = rows * (cellSize + padding) - padding;
        Vector3 gridStartPosition = new Vector3(-totalGridWidth / 2f + cellSize / 2f, totalGridHeight / 2f - cellSize / 2f, 0f);
        gridStartPosition += gridBackground.position;

        for (int row = 0; row < rows; row++)
        {
            for (int col = 0; col < cols; col++)
            {
                Vector3 position = gridStartPosition + new Vector3(col * (cellSize + padding), -row * (cellSize + padding), 0);
                gridPositions[row, col] = position;
                Instantiate(gridBackgroundPrefab, position, Quaternion.identity, gridBackground);
            }
        }
    }

    void SpawnRedAndBlackHole()
    {
        // Spawn Red Hole
        redRow = levelData[grid4levels - 1].redPosition.x;
        redCol = levelData[grid4levels - 1].redPosition.y;
        Vector3 redPosition = gridPositions[redRow, redCol];
        
        gridOccupied[redRow, redCol] = true;  // Mark the grid position as occupied
        GameObject obj =   Instantiate(redPrefab, redPosition, Quaternion.identity);

        SpawnedObjectData redHole = new SpawnedObjectData(obj.name, redRow, redCol);
        spawnedObjects.Add(redHole);

        // Spawn Black Hole
        blackRow = levelData[grid4levels - 1].blackPosition.x;
        blackCol = levelData[grid4levels - 1].blackPosition.y;
        Vector3 blackPosition = gridPositions[blackRow, blackCol];
        //    gridOccupied[blackRow, blackCol] = true;  // Mark the grid position as occupied
       GameObject obj2 =  Instantiate(blackHolePrefab, blackPosition, Quaternion.identity);

        redHole = new SpawnedObjectData(obj2.name, blackRow, blackCol);
        spawnedObjects.Add(redHole);
    }

    void PlaceObstacles()
    {
        int countofObstacles = 0;
        foreach (var obstacle in levelData[grid4levels - 1].obstacles)
        {
            
            int startRow = obstacle.position.x;
            int startCol = obstacle.position.y;
            int height = obstacle.size.y;
            int width = obstacle.size.x;
            countofObstacles++;
            PlaceObstacleAt(startRow, startCol, height, width, obstacle.isStatic , countofObstacles);
        }
    }

    void PlaceObstacleAt(int startRow, int startCol, int height, int width, bool isStatic , int countName)
    {
        Vector3 vector3 = gridPositions[startRow, startCol];
        GameObject obstacle = Instantiate(obstaclePrefab, gridPositions[startRow, startCol], Quaternion.identity);
        obstacle.transform.SetParent(gridBackground);
        obstacle.transform.localScale = new Vector3(width * cellSize, height * cellSize, 1f);

        string CName = "Obstacle" + countName;
        obstacle.name = CName;
        SpawnedObjectData redHole = new SpawnedObjectData(obstacle.name, startRow, startCol);
        spawnedObjects.Add(redHole);

        Vector3 startPos = gridPositions[startRow, startCol];
        obstacle.transform.position = startPos;
        int RanColor = Random.Range(0,ObstaclesColors.Length);
        while (ColorsUsedList.Contains(RanColor))
        {
            RanColor = Random.Range(0, ObstaclesColors.Length); // select a random Color from the list
        }

        ColorsUsedList.Add(RanColor);
        // Enable or disable the SlideableObstacle component based on isStatic
        obstacle.GetComponent<SpriteRenderer>().color = ObstaclesColors[RanColor];

        var slideableComponent = obstacle.GetComponent<SlideableObstacle>();
        if (slideableComponent != null)
        {
            slideableComponent.enabled = !isStatic;

            if (isStatic) {
                obstacle.GetComponent<SpriteRenderer>().color = UnityEngine.Color.white;
                obstacle.GetComponent<SpriteRenderer>().sprite = bgSprites[0];
            }
        }

        // Mark the grid as occupied
        for (int row = startRow; row < startRow + height; row++)
        {
            for (int col = startCol; col < startCol + width; col++)
            {
                if (row >= 0 && row < rows && col >= 0 && col < cols)
                {
                    gridOccupied[row, col] = true;
                   
                }
                else
                {
                    Debug.LogWarning($"Attempted to mark out-of-bounds cell: Row: {row}, Col: {col}");
                }
            }
        }

    }
}
