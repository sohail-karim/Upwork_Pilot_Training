using UnityEngine;
using System.Collections;

public class RedObjectMovement : MonoBehaviour
{
    private Vector3[,] gridPositions;
    private int currentRow, currentCol;
    private Vector3 currentPosition;
    private bool isMoving = false;
    private bool isTouchingRedBall = false;
    private bool isInCooldown = false; // Cooldown flag

    public float cooldownDuration = 0.02f; // Cooldown duration after touch ends
    public float minSwipeDuration = 0.05f; // Minimum swipe duration to avoid extremely fast movements
    public float maxSpeed = 10f; // Maximum speed of the ball to prevent it from moving too fast

    private MotionGridManager gridManager;

    private Vector2 touchStartPos;
    private float touchStartTime; // Record the time when the touch starts

    void Start()
    {
        gridManager = MotionGridManager.instance;
        gridPositions = gridManager.gridPositions;

        currentPosition = transform.position;

        currentRow = gridManager.redRow;
        currentCol = gridManager.redCol;

        Debug.Log("Row: " + currentRow + " Col: " + currentCol);

        // Mark initial position as occupied by the red ball
        gridManager.gridOccupied[currentRow, currentCol] = true;
    }

    void Update()
    {
        if (isMoving || isInCooldown) return; // Check for cooldown

        HandleTouchInput();
    }

    void HandleTouchInput()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    OnTouchBegan(touch);
                    break;

                case TouchPhase.Moved:
                    OnTouchMoved(touch);
                    break;

                case TouchPhase.Ended:
                    OnTouchEnded(touch);
                    break;
            }
        }
    }

    void OnTouchBegan(Touch touch)
    {
        Ray ray = Camera.main.ScreenPointToRay(touch.position);
        if (Physics.Raycast(ray, out RaycastHit hit) && hit.transform == transform)
        {
            // Touch started on the red ball
            isTouchingRedBall = true;
            touchStartPos = touch.position;
            touchStartTime = Time.time; // Record the time when the touch starts
        }
    }

    void OnTouchMoved(Touch touch)
    {
        if (!isTouchingRedBall) return;

        Vector2 touchCurrentPos = touch.position;
        Vector2 swipeVector = touchCurrentPos - touchStartPos;

        // Flip the Y-axis for Unity world coordinates
        swipeVector.y *= -1;

        // Determine movement direction based on swipe distance threshold
        float swipeThreshold = 20f; // Set your desired threshold value

        if (swipeVector.magnitude > swipeThreshold)
        {
            Vector3 direction = Vector3.zero;
            if (Mathf.Abs(swipeVector.x) > Mathf.Abs(swipeVector.y))
            {
                // Horizontal swipe
                direction = swipeVector.x > 0 ? Vector3.right : Vector3.left;
            }
            else
            {
                // Vertical swipe
                direction = swipeVector.y > 0 ? Vector3.up : Vector3.down;
            }

            float swipeDuration = Time.time - touchStartTime; // Calculate swipe duration
            if (swipeDuration < minSwipeDuration)
            {
                swipeDuration = minSwipeDuration; // Ensure minimum swipe duration to avoid extremely fast movements
            }

            float moveSpeed = Mathf.Clamp(swipeVector.magnitude / swipeDuration, 0, maxSpeed); // Calculate swipe speed with a maximum limit
            MoveRedObjectContinuously(direction, moveSpeed);
        }
    }

    void OnTouchEnded(Touch touch)
    {
        if (!isTouchingRedBall) return;

        isTouchingRedBall = false;

        // Snap to nearest grid position
        Vector3 nearestGridPosition = GetNearestGridPosition(transform.position);
        StartCoroutine(MoveToPosition(nearestGridPosition, 0.1f)); // Use a small time to move for instant snap

        // Start cooldown
        StartCoroutine(Cooldown());
    }

    void MoveRedObjectContinuously(Vector3 direction, float moveSpeed)
    {
        int newRow = currentRow;
        int newCol = currentCol;

        if (direction == Vector3.up && currentRow < gridManager.rows - 1)
            newRow = currentRow + 1;
        else if (direction == Vector3.down && currentRow > 0)
            newRow = currentRow - 1;
        else if (direction == Vector3.left && currentCol > 0)
            newCol = currentCol - 1;
        else if (direction == Vector3.right && currentCol < gridManager.cols - 1)
            newCol = currentCol + 1;

        if (CanMoveTo(newRow, newCol))
        {
            Vector3 targetPosition = gridPositions[newRow, newCol];
            float distance = Vector3.Distance(transform.position, targetPosition);
            float timeToMove = distance / moveSpeed; // Calculate time to move based on swipe speed

            StartCoroutine(MoveToPosition(targetPosition, timeToMove));

            // Update grid occupancy
            gridManager.gridOccupied[currentRow, currentCol] = false;
            gridManager.gridOccupied[newRow, newCol] = true;

            currentRow = newRow;
            currentCol = newCol;
            currentPosition = targetPosition;

            if (newRow == gridManager.blackRow && newCol == gridManager.blackCol)
            {
                Debug.Log("You reached the black hole! You win!");
                StartCoroutine(LevelComplete());
            }
        }
    }

    IEnumerator MoveToPosition(Vector3 target, float timeToMove)
    {
        isMoving = true;
        float elapsedTime = 0f;
        Vector3 startingPos = transform.position;

        while (elapsedTime < timeToMove)
        {
            transform.position = Vector3.Lerp(startingPos, target, elapsedTime / timeToMove);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        transform.position = target;
        isMoving = false;
    }

    Vector3 GetNearestGridPosition(Vector3 position)
    {
        float minDistance = float.MaxValue;
        Vector3 nearestPosition = position;

        for (int row = 0; row < gridManager.rows; row++)
        {
            for (int col = 0; col < gridManager.cols; col++)
            {
                Vector3 gridPos = gridPositions[row, col];
                float distance = Vector3.Distance(position, gridPos);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    nearestPosition = gridPos;
                }
            }
        }

        return nearestPosition;
    }

    bool CanMoveTo(int targetRow, int targetCol)
    {
        // Allow moving to the black hole position regardless of obstacles
        if (targetRow == gridManager.blackRow && targetCol == gridManager.blackCol)
            return true;

        // Check for grid boundaries and obstacles
        return targetRow >= 0 && targetRow < gridManager.rows &&
               targetCol >= 0 && targetCol < gridManager.cols &&
               !gridManager.gridOccupied[targetRow, targetCol];
    }

    IEnumerator Cooldown()
    {
        isInCooldown = true;
        yield return new WaitForSeconds(cooldownDuration);
        isInCooldown = false;
    }

    IEnumerator LevelComplete()
    {
        yield return new WaitForSeconds(1f);
        gridManager.CurrentLevel++;
        gridManager.PuzzleSolved++;
        gridManager.StartMotionGame();
    }
}



// this is working fine at 08:38 but lagging a small at every grid point in mobile.