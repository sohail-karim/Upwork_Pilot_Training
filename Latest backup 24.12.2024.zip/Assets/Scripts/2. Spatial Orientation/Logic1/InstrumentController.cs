using System.Collections;
using UnityEngine;

public class InstrumentManager : MonoBehaviour
{
    public Transform airplanceTransform;  // Airplane transform in the instrument
    public Transform ArrowTransform; // Reference to an indicator's transform
    public Transform gyroTransform;      // GYRO instrument's transform (compass)

    private SilhouetteManager silhouetteManager; // Reference to the silhouette manager

    // Array of possible rotation angles
    private int[] possibleRotations = { 0, 90, 180, 270, 360 };

    private static InstrumentManager _instance;

    public static InstrumentManager instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<InstrumentManager>();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
    }

    void Start()
    {
        silhouetteManager = SilhouetteManager.instance;
        SetRandomRotation(); // Initialize with random rotations
    }

    /// <summary>
    /// Set random rotations for GYRO, airplane, and silhouette.
    /// </summary>
    void SetRandomRotation()
    {
        int planeRotation = 0, arrowRotation = 0, gyroRotation = 0;

        do
        {
            // Randomize the plane's rotation in multiples of 15� between -180 and 180
            planeRotation = Random.Range(-12, 13) * 15; // Random range between -180 to 180 in steps of 15
            Debug.Log("Plane Rotation calculated: " + planeRotation);

            // Calculate the arrow's rotation to ensure the total (plane + arrow) = 45� modulo 360
            arrowRotation = (45 - planeRotation + 360) % 360;

            // Randomly decide on the gyro rotation: Allow both positive and negative multiples of 45
            bool randomPosition = Random.Range(0, 2) == 1;
            gyroRotation = randomPosition
                ? possibleRotations[Random.Range(0, possibleRotations.Length)] // Random from predefined values
                : Random.Range(-4, 5) * 45; // Random range between -180 and 180 in steps of 45

        } while (planeRotation + gyroRotation > 180 || planeRotation + gyroRotation < -180 ); // Ensure the sum is between -180 and 180

        Debug.Log("Plane Rotation After Loop: " + planeRotation);

        // Apply the rotations using eulerAngles
        airplanceTransform.eulerAngles = new Vector3(0, 0, planeRotation);
        gyroTransform.eulerAngles = new Vector3(0, 0, gyroRotation);
        ArrowTransform.eulerAngles = new Vector3(0, 0, arrowRotation);

        // Debugging: Log the results
        Debug.Log($"Plane Rotation: {airplanceTransform.eulerAngles.z}, Arrow Rotation: {ArrowTransform.eulerAngles.z}, Gyro Rotation: {gyroTransform.eulerAngles.z}, Combined: {(planeRotation + arrowRotation) % 360}");

        // Pass the correct rotations to the silhouette manager
        silhouetteManager.SetRandomSilhouetteRotations(planeRotation, gyroRotation , arrowRotation);
    }


    /// <summary>
    /// Calculate the silhouette rotation based on GYRO and airplane rotations.
    /// </summary>
    /// <param name="gyroRotation">Current GYRO rotation</param>
    /// <param name="airplaneRotation">Current airplane rotation</param>
    /// <returns>Silhouette rotation angle</returns>
    float CalculateSilhouetteRotation(float gyroRotation, float airplaneRotation)
    {
        // Combine GYRO and airplane rotations for silhouette
        return (gyroRotation + airplaneRotation) % 360; // Keep the value between 0-359 degrees
    }

    /// <summary>
    /// Triggered via a button to randomize rotations.
    /// </summary>
    public void ChangeRotations()
    {
        ResetRotations();
        SetRandomRotation();
    }


    private void ResetRotations()
    {
        airplanceTransform.rotation = Quaternion.Euler(0, 0, 0);
        ArrowTransform.rotation = Quaternion.Euler(0, 0, 0);
        gyroTransform.rotation = Quaternion.Euler(0, 0, 0);
    }
}
