using System.Collections;
using UnityEngine;

public class TrailScript : MonoBehaviour
{
    SpriteRenderer spriteRenderer;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        StartCoroutine(FadeSpriteAlpha(0.25f));
    }



    IEnumerator FadeSpriteAlpha(float time)
    {
        
        for (float t = 0; t < 1; t += Time.deltaTime / time)
        {
            spriteRenderer.color = new Color(spriteRenderer.color.r, spriteRenderer.color.g, spriteRenderer.color.b,Mathf.Lerp(1.0f,0.0f,t)); 
            yield return null;
        }
        Destroy(gameObject);
    }
    
}
