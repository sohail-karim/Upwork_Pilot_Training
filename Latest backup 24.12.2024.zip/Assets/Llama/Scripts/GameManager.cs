
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField]
    private int level;

    public MovableObject currentObjectScript;
    private Touch currentTouch;
    public LayerMask touchLayerMask;
    public bool hasControls;
    private Vector3 currentTouchStartPosition;
    public bool directionDecided;
    private bool moveDirection;//if true, move on X, if false, move on Y

    void Start()
    {
        hasControls = true;
        directionDecided = false;
    }

    // Update is called once per frame
    void Update()
    {
        //If controls are enabled
        if (hasControls)
        {
            if (Input.touchCount > 0)
            {
                currentTouch = Input.GetTouch(0);

                if (currentTouch.phase == TouchPhase.Began)
                {
                    Vector2 touchPosition = currentTouch.position;
                    currentTouchStartPosition = currentTouch.position;

                    // Convert the screen position to world space
                    Vector2 worldPosition = Camera.main.ScreenToWorldPoint(touchPosition);

                    // Perform a raycast at the world position
                    RaycastHit2D hit = Physics2D.Raycast(worldPosition, Vector2.zero, 1.0f, touchLayerMask);

                    // Check if the raycast hit something
                    if (hit.collider != null)
                    {
                        currentObjectScript = hit.collider.GetComponent<MovableObject>();
                        //Enable trail
                        currentObjectScript.isMoving = true;
                        Debug.Log($"Hit object: {hit.collider.name}");
                    }
                    else
                    {
                        Debug.Log("No object hit");
                    }
                }
            }
            //If we hold an object
            if (currentObjectScript != null)
            {
                //If touch is moving
                if(currentTouch.phase == TouchPhase.Moved)
                {
                    //If touch direction is not decided
                    if (!directionDecided)
                    {
                        directionDecided = true;
                        if(Mathf.Abs(currentTouchStartPosition.x - currentTouch.position.x) > Mathf.Abs(currentTouchStartPosition.y - currentTouch.position.y))
                        {
                            moveDirection = true;
                        }
                        else
                        {
                            moveDirection = false;
                        }
                    }
                    //If touch direction is set
                    else
                    {
                        //Get touch position in world space
                        Vector2 touchPosition = currentTouch.position;
                        // Convert the screen position to world space
                        Vector2 worldPosition = Camera.main.ScreenToWorldPoint(touchPosition);
                        //If direction is X
                        if (moveDirection)
                        {
                            currentObjectScript.transform.position = new Vector3(worldPosition.x, currentObjectScript.transform.position.y, 0.0f);
                        }
                        else
                        {
                            currentObjectScript.transform.position = new Vector3(currentObjectScript.transform.position.x, worldPosition.y, 0.0f);
                        }
                        

                    }
                }

                if(currentTouch.phase == TouchPhase.Ended)
                {
                    currentObjectScript.SnapOnGrid();
                    currentObjectScript = null;
                    directionDecided = false;
                }

            }
        }
        
        
    }
}
