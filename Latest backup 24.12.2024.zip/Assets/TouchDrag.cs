using System.Collections;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class TouchDrag : MonoBehaviour
{
    [Space] // Gameobjects
    GameObject currentObject;

    [Space] // float
    public float maxSpeed = 10f; // Maximum speed of the ball to prevent it from moving too fast
    private float touchStartTime; // Record the time when the touch starts
    public float minSwipeDuration = 0.05f; // Minimum swipe duration to avoid extremely fast movements

    [Space] // Vector2
    private Vector2 touchStartPos;

    [Space] // Classes
    private MotionGridManager gridManager;


    void Start()
    {
        gridManager = MotionGridManager.instance;
    }


    void Update()
    {
        HandleTouchInput();
    }

    void HandleTouchInput()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    OnTouchBegan(touch);
                    break;

                case TouchPhase.Moved:
                    onTouchMoved(touch);
                    break;

                case TouchPhase.Ended:
                    onTouchEnded(touch);
                    break;
            }
        }
    }

    void OnTouchBegan(Touch touch)
    {
        Ray ray = Camera.main.ScreenPointToRay(touch.position);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
                currentObject = hit.collider.gameObject;
                currentObject.tag = "Player";
                GetCurrentGridPosition(currentObject.name);
                touchStartPos = touch.position;
                touchStartTime = Time.time; // Record the time when the touch starts

        }
    }

    void onTouchMoved(Touch touch)
    {
        if (currentObject.tag == "Untagged") return;

        Vector2 touchDelta = touch.position - touchStartPos;
        touchDelta.y *= -1;

        float swipeThreshold = 20f; // Set your desired threshold value

        if (touchDelta.magnitude > swipeThreshold)
        {
            Vector3 direction = Vector3.zero;
            if (Mathf.Abs(touchDelta.x) > Mathf.Abs(touchDelta.y))
            {
                // Horizontal swipe
                direction = touchDelta.x > 0 ? Vector3.right : Vector3.left;
            }
            else
            {
                // Vertical swipe
                direction = touchDelta.y > 0 ? Vector3.up : Vector3.down;
            }

            float swipeDuration = Time.time - touchStartTime; // Calculate swipe duration
            if (swipeDuration < minSwipeDuration)
            {
                swipeDuration = minSwipeDuration; // Ensure minimum swipe duration to avoid extremely fast movements
            }

            float moveSpeed = Mathf.Clamp(touchDelta.magnitude / swipeDuration, 0, maxSpeed); // Calculate swipe speed with a maximum limit
        }
    }

    void onTouchEnded(Touch touch)
    {
        currentObject.tag = "Untagged";
    }

    void GetCurrentGridPosition(string pos)
    {
        foreach (SpawnedObjectData obj in gridManager.spawnedObjects)
        {
            if (obj.position == pos)
            {
                Debug.Log("Rows: " + obj.row + " Columns: " + obj.column);
                break;
            }
        }
    }
}