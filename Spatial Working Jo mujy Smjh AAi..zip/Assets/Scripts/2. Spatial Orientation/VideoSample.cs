using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VideoSample : MonoBehaviour
{
    public Transform Plane;
    public Transform Gyro;
    public Transform Arrow;


    public List<int> rotationAngles =  new List<int>();

    private void Start()
    {
        
    }

    public  void StartDisplay()
    {

    }


    IEnumerator StartRotation()
    {
        for (int i = 0; i < 10; i++) { 

            int planeRotation = Random.Range(0, rotationAngles.Count);
            List<int> temp = new List<int>();
            while (!temp.Contains(planeRotation)) {
                temp.Add(planeRotation);
            }

        }

        yield return null;
    }
}
