using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class SilhouetteManager : MonoBehaviour
{
    public Transform airplaneTransform;    // Reference to the airplane
    public Transform[] silhouetteTransforms; // Array of silhouettes
    public Button[] silhouetteButtons;     // Array of buttons linked to silhouettes



    //References
    GridPointCalculation gridPointCalculation;
     
    int correctIndex;
    // Store the rotation of the airplane

    private static SilhouetteManager _instance;



    public static SilhouetteManager instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<SilhouetteManager>();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
    }

    void Start()
    {

        // Set random rotations for the silhouettes
        //    SetRandomSilhouetteRotations();

        // Add listeners to the buttons to check answers
        for (int i = 0; i < silhouetteButtons.Length; i++)
        {
            int index = i;  // To avoid closure issue in lambda
            silhouetteButtons[i].onClick.AddListener(() => CheckAnswer(index));
        }
        gridPointCalculation = GridPointCalculation.instance;

    }

    public void SetRandomSilhouetteRotations(float airplaneRotation, float gyroRotation , float ArrowRotation)
    {
        // Reset silhouette rotations to ensure no leftover values
        ResetSilhouetterRotations();

       
        float correctRotation = airplaneRotation - gyroRotation;

        // Randomly select one silhouette to match the airplane's correct rotation
        correctIndex = Random.Range(0, silhouetteTransforms.Length); // Random index for the correct silhouette

        // Loop through all silhouettes
        for (int i = 0; i < silhouetteTransforms.Length; i++)
        {
            if (i == correctIndex) // The selected silhouette matches the correct rotation
            {
                Debug.Log($"Correct silhouette at index {i+1} with Rotation: {correctRotation}");
                if(correctRotation > 180)
                {
                    Debug.LogError("It was Greater so we subtracted from 360");
                    correctRotation -= 360;

                }
                silhouetteTransforms[i].eulerAngles = new Vector3(0, 0, correctRotation); // Set correct rotation

               FindObjectOfType<GridPointCalculation>().GetCorrectGridPoint(correctRotation, ArrowRotation);
            }
            else // Other silhouettes get random rotations
            {
                // Ensure incorrect rotations do not accidentally match the correct one
                float randomRotation;
                do
                {
                    randomRotation = Random.Range(0f, 360f); // Generate a random rotation
                } while (Mathf.Approximately(randomRotation, correctRotation)); // Avoid matching correct rotation

                silhouetteTransforms[i].rotation = Quaternion.Euler(0, 0, randomRotation); // Set random rotation
            }
        }
    }



    // Method to check if the selected silhouette matches the airplane's rotation
    public void CheckAnswer(int selectedIndex)
    {

        // Get the Image component of the selected silhouette
        Image selectedImage = silhouetteTransforms[selectedIndex].GetComponentInParent<Image>();

        // Change the alpha of the selected silhouette to 255 (fully opaque)
        Color newColor = selectedImage.color;
        newColor.a = 1f;  // Set alpha to 1 (fully opaque)
        selectedImage.color = newColor;  // Apply the new color to the image

        // Check if the selected silhouette is the correct one
        if (selectedIndex == correctIndex)  // If the correct silhouette is clicked
        {
            Debug.Log("Correct! This silhouette matches the airplane.");

        }
        else  // If the incorrect silhouette is clicked
        {
            Debug.Log("Incorrect! This silhouette does not match the airplane.");
        }
    }


    private void ResetSilhouetterRotations()
    {
        // Rotate the silhouettes: one matches the correct rotation, others are random
        for (int i = 0; i < silhouetteTransforms.Length; i++)
        {
            silhouetteTransforms[i].rotation = Quaternion.Euler(0, 0, 0);
        }
    }
}
