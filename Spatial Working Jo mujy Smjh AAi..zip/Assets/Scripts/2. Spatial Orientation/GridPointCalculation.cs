using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridPointCalculation : MonoBehaviour
{

    private static GridPointCalculation _instance;
    [SerializeField]
    float planeRotation = 255f;
    [SerializeField]
    float arrowRotation = 285f;


    public static GridPointCalculation instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<GridPointCalculation>();
            }
            return _instance;
        }
    }


    private void Awake()
    {
        _instance = this;
    }


    private void Start()
    {
       

        int correctGrid = GetCorrectGridPoint(planeRotation, arrowRotation);
        Debug.Log("The correct grid point is: " + correctGrid);
    }

    // The grid layout
    // 8 - 1 - 2
    // 7 - * - 3
    // 6 - 5 - 4
    // The "*" represents the center point

    // Function to get the correct grid point
    public int GetCorrectGridPoint(float planeRotation, float arrowRotation)
    {

        // Iterate through each grid and check if the plane and arrow directions align
        for (int i = 0; i < 9; i++)
        {
            // Get the direction of the plane for the current grid point
            Vector3 gridDirection = GetGridDirection(i);

            // Check if the arrow direction points towards the center
            if (IsArrowPointingToCenter(planeRotation, arrowRotation, gridDirection))
            {
                return i;
            }
        }

        // Return -1 if no grid matches (should not happen if logic is correct)
        return -1;
    }

    // Get the direction of the grid point
    private Vector3 GetGridDirection(int gridIndex)
    {
        switch (gridIndex)
        {
            case 0: return new Vector3(0, 1, 0); // Grid 1 (above center)
            case 1: return new Vector3(1, 1, 0); // Grid 2 (top-right diagonal)
            case 2: return new Vector3(1, 0, 0); // Grid 3 (right of center)
            case 3: return new Vector3(1, -1, 0); // Grid 4 (bottom-right diagonal)
            case 4: return new Vector3(0, -1, 0); // Grid 5 (below center)
            case 5: return new Vector3(-1, -1, 0); // Grid 6 (bottom-left diagonal)
            case 6: return new Vector3(-1, 0, 0); // Grid 7 (left of center)
            case 7: return new Vector3(-1, 1, 0); // Grid 8 (top-left diagonal)
            case 8: return new Vector3(0, 0, 0); // Grid * (center)
            default: return Vector3.zero;
        }
    }


    // Check if the arrow is pointing towards the center based on the plane rotation
    private bool IsArrowPointingToCenter(float planeRotation, float arrowRotation, Vector3 gridDirection)
    {
       
        // Find the relative angle between the plane and arrow
        float relativeAngle = arrowRotation - planeRotation;

        // Check if the relative angle matches the grid direction
        if (relativeAngle < 0)
        {
            relativeAngle += 360;
        }

        float gridAngle = Mathf.Atan2(gridDirection.y, gridDirection.x) * Mathf.Rad2Deg;
        if (Mathf.Abs(relativeAngle - gridAngle) < 15f) // Allowing a margin of error of 15 degrees
        {
            return true;
        }

        return false;
    }
}
