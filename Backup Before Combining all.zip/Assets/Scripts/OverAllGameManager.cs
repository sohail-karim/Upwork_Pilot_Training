using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class OverAllGameManager : MonoBehaviour
{
   
    public LevelInfo[] levelinfo;

    public TextMeshProUGUI levelText;
    public TextMeshProUGUI levelDescriptionText;
    public Button StartLevelButton;

    public GameObject GameStartinfoPanel;


    private void Start()
    {
        GameStartinfoPanel.SetActive(false);
    }

    public void SceneChanage(int SceneNumber)
    {
        GameStartinfoPanel.SetActive(true);
        levelText.text = levelinfo[SceneNumber - 1].levelTextName;
        levelDescriptionText.text = levelinfo[SceneNumber - 1].levelTextDescription;
        StartLevelButton.onClick.AddListener(() => LoadScene(SceneNumber));
    }

    public void LoadScene(int SceneNumber)
    {
        SceneManager.LoadScene(SceneNumber);
    }
}

[System.Serializable]
public struct LevelInfo
{
    public int levelNumber;
    public string levelTextName;
    public string levelTextDescription;
}


