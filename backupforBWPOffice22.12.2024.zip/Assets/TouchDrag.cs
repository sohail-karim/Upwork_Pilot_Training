using UnityEngine;

public class TouchDrag : MonoBehaviour
{
    private Vector3 offset;
    private bool dragging = false;

    void Update()
    {
        // Check if there are any touches
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            // Handle touch phases
            switch (touch.phase)
            {
                case TouchPhase.Began:
                    // Check if the touch is on the object
                    Ray ray = Camera.main.ScreenPointToRay(touch.position);
                    RaycastHit hit;

                    if (Physics.Raycast(ray, out hit) && hit.transform == transform)
                    {
                        dragging = true;
                        offset = transform.position - GetWorldPosition(touch.position);
                    }
                    break;

                case TouchPhase.Moved:
                    // Move the object
                    if (dragging)
                    {
                        Vector3 newPosition = GetWorldPosition(touch.position) + offset;
                        transform.position = newPosition;
                    }
                    break;

                case TouchPhase.Ended:
                case TouchPhase.Canceled:
                    // Stop dragging
                    dragging = false;
                    break;
            }
        }
    }

    // Convert screen position to world position
    private Vector3 GetWorldPosition(Vector2 screenPosition)
    {
        Ray ray = Camera.main.ScreenPointToRay(screenPosition);
        Plane xy = new Plane(Vector3.forward, Vector3.zero);
        float distance;
        xy.Raycast(ray, out distance);
        return ray.GetPoint(distance);
    }
}