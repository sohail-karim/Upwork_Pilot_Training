using UnityEngine;

public class GridGizmo : MonoBehaviour
{
    public MotionGridManager gridManager; // Reference to the grid manager
    public Color occupiedColor = Color.red; // Color for occupied cells
    public float borderWidth = 0.1f;       // Border width of the gizmo

    private void OnDrawGizmos()
    {
        if (gridManager == null || gridManager.gridPositions == null || gridManager.gridOccupied == null)
            return;

        // Loop through the grid
        for (int row = 0; row < gridManager.rows; row++)
        {
            for (int col = 0; col < gridManager.cols; col++)
            {
                if (gridManager.gridOccupied[row, col]) // Check if the cell is occupied
                {
                    DrawCellBorder(gridManager.gridPositions[row, col], gridManager.cellSize);
                }
            }
        }
    }

    private void DrawCellBorder(Vector3 cellCenter, float cellSize)
    {
        // Calculate the corner positions of the cell
        float halfSize = cellSize / 2f;
        Vector3 topLeft = new Vector3(cellCenter.x - halfSize, cellCenter.y + halfSize, cellCenter.z);
        Vector3 topRight = new Vector3(cellCenter.x + halfSize, cellCenter.y + halfSize, cellCenter.z);
        Vector3 bottomLeft = new Vector3(cellCenter.x - halfSize, cellCenter.y - halfSize, cellCenter.z);
        Vector3 bottomRight = new Vector3(cellCenter.x + halfSize, cellCenter.y - halfSize, cellCenter.z);

        // Set the gizmo color
        Gizmos.color = occupiedColor;

        // Draw the borders
        Gizmos.DrawLine(topLeft, topRight);        // Top border
        Gizmos.DrawLine(topRight, bottomRight);   // Right border
        Gizmos.DrawLine(bottomRight, bottomLeft); // Bottom border
        Gizmos.DrawLine(bottomLeft, topLeft);     // Left border
    }
}
