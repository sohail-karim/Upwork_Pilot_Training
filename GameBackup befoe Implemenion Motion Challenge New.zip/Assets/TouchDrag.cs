using System.Collections;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using static UnityEngine.GraphicsBuffer;

public class TouchDrag : MonoBehaviour
{
    [Space] // Gameobjects
    GameObject currentObject;

    private int currentRow, currentCol;

    [Space] // Bools
    public bool directionDecided;
    bool isEndingMovement;
    
    [SerializeField]private bool moveDirection;

    [Space] // float
    public float maxSpeed = 10f; // Maximum speed of the ball to prevent it from moving too fast
    private float touchStartTime; // Record the time when the touch starts
    public float minSwipeDuration = 0.05f; // Minimum swipe duration to avoid extremely fast movements

    [Space] // Vector2
    Vector2 touchStartPos;

    [Space] // Vector3
    private Vector3[,] gridPositions;

    [Space] // Classes
    private MotionGridManager gridManager;


    void Start()
    {
        gridManager = MotionGridManager.instance;
        gridPositions = gridManager.gridPositions;
        currentObject = null;
    }


    void Update()
    {
        HandleTouchInput();

        if (isEndingMovement)
        {
            Vector3 nearestGridPosition = GetNearestGridPosition(currentObject.transform.position);
            MoveToPosition(nearestGridPosition,0.1f);
            currentObject.tag = "Untagged";
            currentObject = null;
            isEndingMovement = false;
            
        }
    }

    void HandleTouchInput()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    OnTouchBegan(touch);
                    break;

                case TouchPhase.Moved:
                    if(currentObject != null) onTouchMoved(touch);
                    break;

                case TouchPhase.Ended:
                    onTouchEnded(touch);
                    break;
            }
        }
    }

    void OnTouchBegan(Touch touch)
    {
        Ray ray = Camera.main.ScreenPointToRay(touch.position);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
                currentObject = hit.collider.gameObject;
                currentObject.tag = "Player";
                GetCurrentGridPosition(currentObject.name);
                touchStartPos = touch.position;
                touchStartTime = Time.time; // Record the time when the touch starts
        }
    }

    void onTouchMoved(Touch touch)
    {
        if (currentObject == null) return;


        //If touch direction is not decided
        if (!directionDecided)
        {
            directionDecided = true;
            if (Mathf.Abs(touchStartPos.x - touch.position.x) > Mathf.Abs(touchStartPos.y - touch.position.y))
            {
                moveDirection = true;
            }
            else
            {
                moveDirection = false;
            }
        }
        else
        {
            //Get touch position in world space
            Vector2 touchPosition = touch.position;
            // Convert the screen position to world space
            Vector2 worldPosition = Camera.main.ScreenToWorldPoint(touchPosition);
            //If direction is X
            if (moveDirection)
            {
                currentObject.transform.position = new Vector3(worldPosition.x, currentObject.transform.position.y, 0.0f);
            }
            else
            {
                currentObject.transform.position = new Vector3(currentObject.transform.position.x, worldPosition.y, 0.0f);
            }
        }
    }

    void onTouchEnded(Touch touch)
    {
        if (currentObject == null) return;
        isEndingMovement = true;
        directionDecided = false;
    }


    void MoveRedObjectContinuously(Vector3 direction, float moveSpeed)
    {
        int newRow = currentRow;
        int newCol = currentCol;

        if (direction == Vector3.up && currentRow < gridManager.rows - 1)
            newRow = currentRow + 1;
        else if (direction == Vector3.down && currentRow > 0)
            newRow = currentRow - 1;
        else if (direction == Vector3.left && currentCol > 0)
            newCol = currentCol - 1;
        else if (direction == Vector3.right && currentCol < gridManager.cols - 1)
            newCol = currentCol + 1;
        Debug.Log(gridManager.gridPositions[newRow, newCol]);
        if (CanMoveTo(newRow, newCol))
        {
            Vector3 targetPosition = gridManager.gridPositions[newRow, newCol];
            float distance = Vector3.Distance(currentObject.transform.position, targetPosition);
            float timeToMove = distance / moveSpeed; // Calculate time to move based on swipe speed

            MoveToPosition(targetPosition, timeToMove);

            // Update grid occupancy
            gridManager.gridOccupied[currentRow, currentCol] = false;
            gridManager.gridOccupied[newRow, newCol] = true;

            currentRow = newRow;
            currentCol = newCol;
            currentObject.transform.position = targetPosition;

            if (newRow == gridManager.blackRow && newCol == gridManager.blackCol)
            {
                Debug.Log("You reached the black hole! You win!");
             //   StartCoroutine(LevelComplete());
            }
        }
    }

    bool CanMoveTo(int targetRow, int targetCol)
    {
        // Allow moving to the black hole position regardless of obstacles
        if (targetRow == gridManager.blackRow && targetCol == gridManager.blackCol)
            return true;

        // Check for grid boundaries and obstacles
        return targetRow >= 0 && targetRow < gridManager.rows &&
               targetCol >= 0 && targetCol < gridManager.cols &&
               !gridManager.gridOccupied[targetRow, targetCol];
    }

    void MoveToPosition(Vector3 target, float timeToMove)
    {
        float elapsedTime = 0f;
        Vector3 startingPos = currentObject.transform.position;

        while (elapsedTime < timeToMove)
        {
            currentObject.transform.position = Vector3.Lerp(startingPos, target, elapsedTime / timeToMove);
            elapsedTime += Time.deltaTime;
        }
        currentObject.transform.position = target;
    }

    void MoveToPosition(Vector3 target, float timeToMove,bool temp)
    {
        float elapsedTime = 0f;
        Vector3 startingPos = currentObject.transform.position;

        while (elapsedTime < timeToMove)
        {
            currentObject.transform.position = Vector3.Lerp(startingPos, target, elapsedTime / timeToMove);
            elapsedTime += Time.deltaTime;
        }
        currentObject.transform.position = target;
    }


    Vector3 GetNearestGridPosition(Vector3 position)
    {
        float minDistance = float.MaxValue;
        Vector3 nearestPosition = position;

        for (int row = 0; row < gridManager.rows; row++)
        {
            for (int col = 0; col < gridManager.cols; col++)
            {
                Vector3 gridPos =gridManager.gridPositions[row, col];
                float distance = Vector3.Distance(position, gridPos);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    nearestPosition = gridPos;
                }
            }
        }

        return nearestPosition;
    }

    //This is a helper function to get the current grid position of the object on
    //which the touch is started
    void GetCurrentGridPosition(string pos)
    {
        foreach (SpawnedObjectData obj in gridManager.spawnedObjects)
        {
            if (obj.position == pos)
            {
                currentRow = obj.row;
                currentCol = obj.column;
                Debug.Log("Rows: " + currentRow + " Columns: " + currentCol);
                break;
            }
        }
    }
}