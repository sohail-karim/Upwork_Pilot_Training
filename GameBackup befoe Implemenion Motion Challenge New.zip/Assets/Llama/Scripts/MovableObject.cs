using UnityEngine;

public class MovableObject : MonoBehaviour
{
    public Rigidbody2D rb;
    public Transform[] raycastPositions;
    public LayerMask gridLayer;
    public GameManager gameManager;
    public bool isPlayer;
    public bool isMoving;
    public float trailCounter;
    public float trailCounterLimit;
    public GameObject trailPrefab;
    private SpriteRenderer spriteRenderer;
    public Vector3 lastPosition;

    void Awake()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        rb = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        isMoving = false;
        trailCounter = 0.0f;
        trailCounterLimit = 0.1f;
        SnapOnGrid();
    }
    public void SnapOnGrid()
    {
        //Stop rigidbody
        rb.velocity = Vector2.zero;
        //Stop trail
        isMoving = false;
        //Modify values in GameManager
        gameManager.directionDecided = false;
        gameManager.currentObjectScript = null;

        Transform[] gridSquaresTransform = new Transform[raycastPositions.Length];
        //Find grid squares below this object
        for (int i = 0; i < raycastPositions.Length; i++)
        {
            RaycastHit2D hit = Physics2D.Raycast(raycastPositions[i].position, Vector2.zero, 1.0f, gridLayer);

            // Check if the raycast hit something
            if (hit.collider != null)
            {
                Debug.Log("Grid square found.");
                gridSquaresTransform[i] = hit.collider.transform;
            }
            //If there is not grid square
            else
            {
                transform.position = lastPosition;
                return;
            }
        }
        //Calculate position to snap to
        Vector3 snapPosition;
        float xPosition = 0f;
        float yPosition = 0f;

        //Calculate xPosition
        for (int i = 0; i < raycastPositions.Length; i++)
        {
            xPosition += gridSquaresTransform[i].position.x;
        }
        xPosition /= raycastPositions.Length;

        //Calculate yPosition
        for (int i = 0; i < raycastPositions.Length; i++)
        {
            yPosition += gridSquaresTransform[i].position.y;
        }
        yPosition /= raycastPositions.Length;

        snapPosition = new Vector3(xPosition, yPosition, 0.0f);

        //Place this object at correct position on grid
        Debug.Log("Snap position = " + xPosition.ToString() + "/" + yPosition.ToString());
        transform.position = snapPosition;

        //Save position
        lastPosition = transform.position;

    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isPlayer)
        {
            if (collision.CompareTag("Obstacle"))
                SnapOnGrid();
            if (collision.CompareTag("EndCircle"))
                rb.velocity = Vector2.zero;
        }
        else
        {
            if (collision.CompareTag("Obstacle") || collision.CompareTag("EndCircle") || collision.CompareTag("Player"))
                SnapOnGrid();
        }

    }

}
