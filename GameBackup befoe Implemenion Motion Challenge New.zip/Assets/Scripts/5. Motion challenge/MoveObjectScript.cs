using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class MoveObjectScript : MonoBehaviour
{
    float touchStartTime;
    bool directionDecided;
    bool hasControls;
    public bool moveDirection;
    public GameObject currentObj;
    private Touch currentTouch;
    Vector3 currentTouchStartPosition;
    private Vector3 targetPosition;
    public float lerpSpeed = 10.0f;



    private void Start()
    {
        hasControls = true;
        directionDecided = false;
    }
    void Update()
    {
        // If controls are enabled
        if (hasControls)
        {
            if (Input.touchCount > 0)
            {
                currentTouch = Input.GetTouch(0);

                if (currentTouch.phase == TouchPhase.Began)
                {
                    Vector2 touchPosition = currentTouch.position;
                    currentTouchStartPosition = currentTouch.position;

                    // Convert the screen position to world space
                    Vector2 worldPosition = Camera.main.ScreenToWorldPoint(touchPosition);
                    Ray ray = Camera.main.ScreenPointToRay(currentTouch.position);
                    // Perform a raycast at the world position
                    

                    // Check if the raycast hit something
                    if (Physics.Raycast(ray, out RaycastHit hit) && hit.collider != null)
                    {
                        currentObj = hit.collider.gameObject;
                        // Enable trail
                        Debug.Log($"Hit object: {hit.collider.name}");
                    }
                    else
                    {
                        Debug.Log("No object hit");
                    }
                }
            }

            // If we hold an object
            if (currentObj != null)
            {
                // If touch is moving
                if (currentTouch.phase == TouchPhase.Moved)
                {
                    // If touch direction is not decided
                    if (!directionDecided)
                    {
                        directionDecided = true;
                        if (Mathf.Abs(currentTouchStartPosition.x - currentTouch.position.x) > Mathf.Abs(currentTouchStartPosition.y - currentTouch.position.y))
                        {
                            moveDirection = true;
                        }
                        else
                        {
                            moveDirection = false;
                        }
                    }
                    // If touch direction is set
                    else
                    {
                        // Get touch position in world space
                        Vector2 touchPosition = currentTouch.position;
                        // Convert the screen position to world space
                        Vector2 worldPosition = Camera.main.ScreenToWorldPoint(touchPosition);
                        Vector3 worldPosition3D = new Vector3(worldPosition.x, worldPosition.y, 0.0f);

                        // Calculate the target position based on touch input
                        if (moveDirection)
                        {
                            targetPosition = new Vector3(worldPosition.x, currentObj.transform.position.y, 0.0f);
                        }
                        else
                        {
                            targetPosition = new Vector3(currentObj.transform.position.x, worldPosition.y, 0.0f);
                        }

                        // Interpolate the position using Lerp
                        currentObj.transform.position = Vector3.Lerp(currentObj.transform.position, targetPosition, lerpSpeed * Time.deltaTime);
                    }
                }

                if (currentTouch.phase == TouchPhase.Ended)
                {
                    directionDecided = false;
                    currentObj = null;
                    
                }
            }
        }
    }
}
