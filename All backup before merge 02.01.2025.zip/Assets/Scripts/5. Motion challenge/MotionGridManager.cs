using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MotionGridManager : MonoBehaviour
{
    public int CurrentLevel;

    [Space]
    int grid4levels;

    [Space]
    public int MovesDone = 0;
    public TextMeshProUGUI text_MoveDone;
    public int PuzzleSolved= 0;

    [Space]
    public TextMeshProUGUI LevelText;
    public TextMeshProUGUI timer_Text;
    public float MaxTime = 300f;
    public float timeRemaining = 300f;
    private bool isTimerRunning = true;
    public Slider slider_timer;

    [Header("Custom Colors")]
    public Color[] ObstaclesColors;
    [HideInInspector] public List<int> ColorsUsedList = new List<int>();


    [Header("Custom levelPlay")]
    public bool PlaycustomLevel = false;
    public int CustomLevel = 1;
    public int TotalLevels;

    [Header("Custom MovementSettings")]
    public Slider lerpSpeed;
    public TextMeshProUGUI lerpSpeedText;

    public Slider MoveSpeed;
    public TextMeshProUGUI MoveSpeedText;




    List<int> PlayerlevelsList = new List<int>();


    public static MotionGridManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }


    void Start()
    {
        lerpSpeed.value = 10;
        MoveSpeed.value = 5;
        isTimerRunning = false;
        slider_timer.maxValue = MaxTime;
        PlayerlevelsList.Clear();
        CurrentLevel = 1;
    }

    void Update()
    {
        if (isTimerRunning)
        {
            if (timeRemaining > 0)
            {
                timeRemaining -= Time.deltaTime; // Decrease time by delta time
              //  slider_timer.value = timeRemaining;
            //    UpdateTimerDisplay();
            }
            else
            {
                isTimerRunning = false;
                timeRemaining = 0;
            //    UpdateTimerDisplay();
                GameOver();
                Debug.Log("Timer has ended.");
            }
        }
    }

    public void GameOver()
    {
        PlayerlevelsList.Clear();
        SceneManager.LoadScene("5. Motion challenge");
        Destroy(gameObject);
    //    StartCoroutine(StartNewGame());
    }
    public void LevelSkip()
    {
        Debug.Log("Skip Level");
        CurrentLevel++;
        StartMotionGame();
    }

    public void UpdatemovesDone()
    {
        MovesDone++;
        text_MoveDone.text = MovesDone.ToString();
    }

    IEnumerator StartNewGame()
    {

        Debug.Log("Solved Puzzled " + PuzzleSolved);
        yield return new WaitForSeconds(1f);
        StartMotionGame();


        yield return null;
    }

    void UpdateTimerDisplay()
    {
        // Convert seconds into minutes and seconds format
        int minutes = Mathf.FloorToInt(timeRemaining / 60);
        int seconds = Mathf.FloorToInt(timeRemaining % 60);

        // Update the Text component
        timer_Text.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

     public  void StartMotionGame()
     {
        
        ColorsUsedList.Clear();
        if (PlaycustomLevel)
        {
            grid4levels = CustomLevel;
            SceneManager.LoadScene("Level" + grid4levels);
            return;
        }

        MovesDone = 0;
        //    text_MoveDone.text = MovesDone.ToString();
        if (PlayerlevelsList.Count == TotalLevels-1)
        {
            Debug.Log("All levels are completed");
            PlayerlevelsList.Clear();
        }

        grid4levels = Random.Range(1, TotalLevels);  // select a random level of 4*4 Grid

        while (PlayerlevelsList.Contains(grid4levels))
        {
            grid4levels = Random.Range(1, TotalLevels);  // select a random level of 4*4 Grid
        }

        PlayerlevelsList.Add(grid4levels);
     //   LevelText.text ="Level " + CurrentLevel.ToString();
        isTimerRunning = true;
        SceneManager.LoadScene("Level"+ grid4levels);
    }



    public void UpdateLerpSpeed()
    {
        lerpSpeedText.text = "Lerp Speed : "+ lerpSpeed.value.ToString();
        MoveSpeedText.text = "Max Speed : " + MoveSpeed.value.ToString();
        PlayerPrefs.SetFloat("LerpSpeed", lerpSpeed.value);
        PlayerPrefs.SetFloat("MaxSpeed", MoveSpeed.value);
    }

}
