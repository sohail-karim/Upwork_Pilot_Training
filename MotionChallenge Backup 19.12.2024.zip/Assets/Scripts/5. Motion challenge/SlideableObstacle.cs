using UnityEngine;

public class SlideableObstacle : MonoBehaviour
{
    private bool isDragging = false;
    private MotionGridManager gridManager;
    private int currentRow, currentCol;
    private Vector3[,] gridPositions;

    private Vector3 mouseStartPos;
    private Vector3 obstacleStartPos;
    private bool moved = false;

    [SerializeField] private int obstacleHeight = 1; // Number of rows the obstacle occupies
    [SerializeField] private int obstacleWidth = 1;  // Number of columns the obstacle occupies

    void Start()
    {
        obstacleWidth = Mathf.CeilToInt(transform.localScale.x);
        obstacleHeight = Mathf.CeilToInt(transform.localScale.y);
        gridManager = MotionGridManager.instance;
        gridPositions = gridManager.gridPositions;

        // Calculate initial grid position
        Vector3 startPos = transform.position;
        currentRow = GetGridRow(startPos.y);
        currentCol = GetGridCol(startPos.x);

        // Mark initial grid cells as occupied
        UpdateGridOccupation(currentRow, currentCol, true);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
            OnMousePressed();
        else if (Input.GetMouseButtonUp(0))
            OnMouseReleased();
    }

    void OnMousePressed()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit) && hit.transform == transform)
        {
            isDragging = true;
            mouseStartPos = GetMouseWorldPosition();
            obstacleStartPos = transform.position;
            moved = false;
        }
    }

    void OnMouseReleased()
    {
        if (!isDragging) return;

        isDragging = false;
        Vector3 mouseEndPos = GetMouseWorldPosition();
        Vector3 dragVector = mouseEndPos - mouseStartPos;

        // Determine movement direction
        Vector3 moveDirection = DetermineDirection(dragVector);
        MoveObstacle(moveDirection);
    }

    private Vector3 DetermineDirection(Vector3 dragVector)
    {
        if (Mathf.Abs(dragVector.x) > Mathf.Abs(dragVector.y))
            return dragVector.x > 0 ? Vector3.right : Vector3.left;
        else
            return dragVector.y > 0 ? Vector3.up : Vector3.down;
    }

    private void MoveObstacle(Vector3 moveDirection)
    {
        int newRow = currentRow;
        int newCol = currentCol;

        // Calculate new position based on move direction
        if (moveDirection == Vector3.up && currentRow > 0) newRow--;
        else if (moveDirection == Vector3.down && currentRow < gridManager.rows - obstacleHeight) newRow++;
        else if (moveDirection == Vector3.left && currentCol > 0) newCol--;
        else if (moveDirection == Vector3.right && currentCol < gridManager.cols - obstacleWidth) newCol++;

        // Validate target position
        if (CanMoveTo(newRow, newCol))
        {
            UpdateGridOccupation(currentRow, currentCol, false); // Free current cells
            UpdateGridOccupation(newRow, newCol, true);          // Occupy new cells

            currentRow = newRow;
            currentCol = newCol;
            gridManager.UpdatemovesDone();
            StartCoroutine(SmoothMove(gridPositions[newRow, newCol]));
        }
        else
        {
            StartCoroutine(SmoothMove(obstacleStartPos)); // Snap back to original position
        }
    }

    private bool CanMoveTo(int targetRow, int targetCol)
    {
        for (int row = targetRow; row < targetRow + obstacleHeight; row++)
        {
            for (int col = targetCol; col < targetCol + obstacleWidth; col++)
            {
                // Ignore cells currently occupied by this obstacle
                if ((row >= currentRow && row < currentRow + obstacleHeight) &&
                    (col >= currentCol && col < currentCol + obstacleWidth))
                    continue;

                // Validate bounds and occupation
                if (row >= gridManager.rows || col >= gridManager.cols || gridManager.gridOccupied[row, col])
                    return false;
            }
        }
        return true;
    }

    private void UpdateGridOccupation(int startRow, int startCol, bool occupied)
    {
        for (int row = startRow; row < startRow + obstacleHeight; row++)
        {
            for (int col = startCol; col < startCol + obstacleWidth; col++)
            {
                if (row < gridManager.rows && col < gridManager.cols)
                {
                    gridManager.gridOccupied[row, col] = occupied;
                }
            }
        }
    }

    System.Collections.IEnumerator SmoothMove(Vector3 target)
    {
        float elapsedTime = 0f;
        float moveTime = 0.2f;

        Vector3 startPosition = transform.position;

        while (elapsedTime < moveTime)
        {
            transform.position = Vector3.Lerp(startPosition, target, elapsedTime / moveTime);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        transform.position = target;
    }

    private Vector3 GetMouseWorldPosition()
    {
        Vector3 mousePoint = Input.mousePosition;
        mousePoint.z = Camera.main.WorldToScreenPoint(transform.position).z;
        return Camera.main.ScreenToWorldPoint(mousePoint);
    }

    private int GetGridRow(float worldY)
    {
        return Mathf.RoundToInt((worldY - gridPositions[0, 0].y) / -gridManager.cellSize);
    }

    private int GetGridCol(float worldX)
    {
        return Mathf.RoundToInt((worldX - gridPositions[0, 0].x) / gridManager.cellSize);
    }
}
