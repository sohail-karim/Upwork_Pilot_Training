using UnityEngine;
using System.Collections;

public class RedObjectMovement : MonoBehaviour
{
    private Vector3[,] gridPositions;
    private int currentRow, currentCol;
    private Vector3 currentPosition;
    private bool isMoving = false;
    private bool isTouchingRedBall = false;

    public float moveSpeed = 5f;

    private MotionGridManager gridManager;

    private Vector2 touchStartPos;
    private Vector2 touchEndPos;

    void Start()
    {
        gridManager = MotionGridManager.instance;
        gridPositions = gridManager.gridPositions;

        currentPosition = transform.position;

        currentRow = gridManager.redRow;
        currentCol = gridManager.redCol;

        Debug.Log("Row: " + currentRow + " Col: " + currentCol);

        // Mark initial position as occupied by the red ball
        gridManager.gridOccupied[currentRow, currentCol] = true;
    }

    void Update()
    {
        if (isMoving) return;

        HandleTouchInput();
    }

    void HandleTouchInput()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    OnTouchBegan(touch);
                    break;

                case TouchPhase.Ended:
                    OnTouchEnded(touch);
                    break;
            }
        }
    }

    void OnTouchBegan(Touch touch)
    {
        Ray ray = Camera.main.ScreenPointToRay(touch.position);
        if (Physics.Raycast(ray, out RaycastHit hit) && hit.transform == transform)
        {
            // Touch started on the red ball
            isTouchingRedBall = true;
            touchStartPos = touch.position;
        }
    }

    void OnTouchEnded(Touch touch)
    {
        if (!isTouchingRedBall) return;

        isTouchingRedBall = false;
        touchEndPos = touch.position;

        Vector2 swipeVector = touchEndPos - touchStartPos;

        // Flip the Y-axis for Unity world coordinates
        swipeVector.y *= -1;

        // Determine movement direction based on swipe
        if (swipeVector.magnitude > 50f) // Minimum swipe threshold
        {
            if (Mathf.Abs(swipeVector.x) > Mathf.Abs(swipeVector.y))
            {
                // Horizontal swipe
                if (swipeVector.x > 0)
                    MoveRedObject(Vector3.right); // Swipe right
                else
                    MoveRedObject(Vector3.left); // Swipe left
            }
            else
            {
                // Vertical swipe
                if (swipeVector.y > 0)
                    MoveRedObject(Vector3.up); // Swipe up
                else
                    MoveRedObject(Vector3.down); // Swipe down
            }
        }

    }

    void MoveRedObject(Vector3 direction)
    {
        int newRow = currentRow;
        int newCol = currentCol;

        if (direction == Vector3.up && currentRow < gridManager.rows - 1)
            newRow = currentRow + 1;
        else if (direction == Vector3.down && currentRow > 0)
            newRow = currentRow - 1;
        else if (direction == Vector3.left && currentCol > 0)
            newCol = currentCol - 1;
        else if (direction == Vector3.right && currentCol < gridManager.cols - 1)
            newCol = currentCol + 1;

        if (CanMoveTo(newRow, newCol))
        {
            Vector3 targetPosition = gridPositions[newRow, newCol];
            StartCoroutine(MoveToPosition(targetPosition));

            // Update grid occupancy
            gridManager.gridOccupied[currentRow, currentCol] = false;
            gridManager.gridOccupied[newRow, newCol] = true;

            currentRow = newRow;
            currentCol = newCol;
            currentPosition = targetPosition;

            if (newRow == gridManager.blackRow && newCol == gridManager.blackCol)
            {
                Debug.Log("You reached the black hole! You win!");
              StartCoroutine( LevelComplete());
            }
        }
    }
    IEnumerator LevelComplete()
    {
        yield return new WaitForSeconds(1f);
        gridManager.CurrentLevel++;
        gridManager.PuzzleSolved++;
        gridManager.StartMotionGame();
    }

  


    bool CanMoveTo(int targetRow, int targetCol)
    {
        // Allow moving to the black hole position regardless of obstacles
        if (targetRow == gridManager.blackRow && targetCol == gridManager.blackCol)
            return true;

        // Check for grid boundaries and obstacles
        return targetRow >= 0 && targetRow < gridManager.rows &&
               targetCol >= 0 && targetCol < gridManager.cols &&
               !gridManager.gridOccupied[targetRow, targetCol];
    }

    IEnumerator MoveToPosition(Vector3 target)
    {
        isMoving = true;

        float timeToMove = 0.2f;
        float elapsedTime = 0f;
        Vector3 startingPos = transform.position;

        while (elapsedTime < timeToMove)
        {
            transform.position = Vector3.Lerp(startingPos, target, elapsedTime / timeToMove);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        transform.position = target;
        gridManager.UpdatemovesDone();
        isMoving = false;
    }
}
