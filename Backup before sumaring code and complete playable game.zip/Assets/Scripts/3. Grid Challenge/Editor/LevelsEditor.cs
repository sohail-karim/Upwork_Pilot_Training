using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Levels))]
public class LevelsEditor : Editor
{
    public override void OnInspectorGUI()
    {
       
    }
}


